package com.simplilearn.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
 
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import com.simplilearn.dao.UserDao;
import com.simplilearn.entity.UserEntity;

@Controller
public class MainController {
	
 
	
	@Autowired
	UserDao dao;

	
	@GetMapping("/listuser")
	public String getAllUsers(ModelMap map) {
		
		
		List<UserEntity> list= dao.getAllUsers();
		map.addAttribute("list", list);
		return "users";
	}

	@GetMapping("/details")
	public String getUser(HttpServletRequest request,ModelMap map) {
			int id=Integer.parseInt(request.getParameter("id"));
			UserEntity entity=dao.getUserById(id);
			map.addAttribute("obj",entity);
			return "details";
	}
			
	@GetMapping("/update")
	public String getUpdate(HttpServletRequest request) {
	int id=Integer.parseInt(request.getParameter("id"));
	String name = request.getParameter("name");
	String email = request.getParameter("email");
	String password = request.getParameter("password");
	
	UserEntity obj = new UserEntity( id, name, email,password);
	String result = dao.updateUser(obj);
	return result;
		
		
}
}