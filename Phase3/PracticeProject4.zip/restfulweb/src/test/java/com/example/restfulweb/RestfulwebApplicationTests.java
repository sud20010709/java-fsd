package com.example.restfulweb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestfulwebApplicationTests {

	@Test
	void contextLoads() {
	}

}
