package com.example.UserFeedback.service;


import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.UserFeedback.bean.Feedback;
import com.example.UserFeedback.repository.FeedbackRepository;

@Service
public class FeedbackService {
	@Autowired
	public FeedbackRepository feedbackRepo;

	public List<Feedback> getAllFeedbacks()
	{
		List<Feedback> feedbacks = new ArrayList<>();
		feedbackRepo.findAll().forEach(feedbacks::add);
		return feedbacks;
	}

	public void addFeedback(Feedback feedback) {
		feedbackRepo.save(feedback);
		
	}

}