package com.example.UserFeedback.controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.UserFeedback.bean.Feedback;
import com.example.UserFeedback.service.FeedbackService;

@RestController
public class FeedbackController {
	@Autowired
	private FeedbackService FeedbackService;

	@RequestMapping("/feedbacks")
	public List<Feedback> getAllFeedbacks()
	{
		return FeedbackService.getAllFeedbacks();
	}
	
	@RequestMapping(method = RequestMethod.POST, value="/feedbacks")
	public void addFeedback(@RequestBody Feedback feedback)
	{
		FeedbackService.addFeedback(feedback);
	}	
}