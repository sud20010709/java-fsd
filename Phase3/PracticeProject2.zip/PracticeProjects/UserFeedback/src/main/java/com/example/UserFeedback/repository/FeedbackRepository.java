package com.example.UserFeedback.repository;


import org.springframework.data.repository.CrudRepository;

import com.example.UserFeedback.bean.Feedback;

public interface FeedbackRepository extends CrudRepository<Feedback,String> {
	


}