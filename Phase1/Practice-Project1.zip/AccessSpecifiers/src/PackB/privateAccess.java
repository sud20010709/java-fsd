package PackB;

public class privateAccess {

//Private Access Specifier

		private String color1= "Blue";
		private String color2= "Red";

}
