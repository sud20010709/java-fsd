package PackB;

public class protectedAccess {

//Protected Access Specifier

		protected String city1= "New York";
		protected String city2= "Paris";

}
