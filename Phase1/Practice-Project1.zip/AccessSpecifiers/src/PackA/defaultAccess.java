package PackA;

//Default Access Specifier

    class defaultAccess {
	String pet1= "Dog";
	String pet2= "Cat";

}
