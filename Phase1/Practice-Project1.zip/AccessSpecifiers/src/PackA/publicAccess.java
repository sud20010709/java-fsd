
package PackA;

public class publicAccess {
	
//Public Access Specifier

	String student1= "Damon Salvatore";
	String student2= "Stefan Salvatore";

}
