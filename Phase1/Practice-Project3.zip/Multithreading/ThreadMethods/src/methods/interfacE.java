package methods;

public class interfacE implements Runnable {
	public void run() {
	for (int i=0;i<=10;i++) {
		System.out.println("Test "+i);
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
	}
	}

	public static void main(String[] args) {
		interfacE obj = new interfacE();
		interfacE obj1 = new interfacE();
		
		Thread t1 = new Thread(obj);
		Thread t2 = new Thread(obj1);
		
		t1.start();
		t2.start();
		

	}

}
