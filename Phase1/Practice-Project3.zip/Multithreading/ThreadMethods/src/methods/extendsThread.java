package methods;

public class extendsThread extends Thread {
	public void run() {
		for(int i = 0;i<=10;i++) {
		System.out.println("Hello " +i);
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
		}

	public static void main(String[] args) {
		extendsThread obj= new extendsThread();
		extendsThread obj1= new extendsThread();
		obj.start();
		obj1.start();
	}

}
