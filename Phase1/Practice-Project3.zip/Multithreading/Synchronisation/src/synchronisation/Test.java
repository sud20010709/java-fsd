package synchronisation;

public class Test {
	
	public static void main(String[] args) {
		
		Sender sender = new  Sender();
		
		User t1= new User("Welcome!", sender);
		
		
		t1.start();
		
	}

}