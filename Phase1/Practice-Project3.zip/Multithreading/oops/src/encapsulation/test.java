package encapsulation;
public class test {

	public static void main(String[] args) {
		student d= new student();
	    d.setId(24);
	    d.setName("Kiki");
	    d.setRollno(23456);
	    
	    System.out.println(d.getId()+"\n" + d.getName() +"\n"+ d.getRollno());
	}

}
