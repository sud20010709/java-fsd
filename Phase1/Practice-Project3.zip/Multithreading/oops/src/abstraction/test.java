package abstraction;
public class test {

	
	public static void main(String[] args) {
		Shape s1= new Circle(1.5, "Red");
		
		
		System.out.println(s1);
		
	}
}