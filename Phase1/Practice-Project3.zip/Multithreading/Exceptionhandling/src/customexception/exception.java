

package customexception;

public class exception extends Exception {
	
	private String msg;

	public exception(String msg) {
		 
		this.msg = msg;
		
	}

	@Override
	public String toString() {
		return "AgeNotValidExecption message=" + msg ;
	}
}
    
	
	
	

	 
	
	

