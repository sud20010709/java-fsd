package customexception;

public class main {
	
	
	static void check(int age) throws exception {
		
		if(age<18)
			throw new exception("User Can not Vote Before 18");
		else
			System.out.println("User can Vote");
		
	}
	
	
	public static void main(String[] args) {
				try {
					check(16);
				} catch (exception e) {
					
					System.out.println(e);
				}
	}
	
	

}
	

